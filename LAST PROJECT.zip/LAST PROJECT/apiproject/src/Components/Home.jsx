import { Link } from "react-router-dom"
import { useState, useEffect } from "react"
import React from "react"
import "./Home.css"

const Home = () => {
  const [currentSlide, setCurrentSlide] = useState(0)

  const heroSlides = [
    {
      id: 1,
      image: "/public/images/hero1.jpg",
      alt: "Urban streetwear collection",
    },
    {
      id: 2,
      image: "/public/images/hero2.jpg",
      alt: "New arrivals collection",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === heroSlides.length - 1 ? 0 : prev + 1))
    }, 5000)

    return () => clearInterval(interval)
  }, [heroSlides.length])

  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-slider">
          {heroSlides.map((slide, index) => (
            <div
              key={slide.id}
              className={`hero-slide ${index === currentSlide ? "active" : ""}`}
              style={{ backgroundImage: `url(${slide.image})` }}
            >
              <div className="hero-content">
                <div className="hero-overlay"></div>
                <div className="hero-text">
                  <h1>UNDERGOLD</h1>
                  <p>Urban Streetwear Collection</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="category-links">
          <Link to="/men" className="category-link">
            MEN
          </Link>
          <Link to="/women" className="category-link">
            WOMEN
          </Link>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="featured-collections">
        <h2>FEATURED COLLECTIONS</h2>
        <div className="collections-grid">
          <div className="collection-item">
            <div className="collection-image">
              <img src="Images/IMAGE 1.jpg" alt="Basics Collection" />
            </div>
            <div className="collection-info">
              <h3>BASICS</h3>
              <Link to="/collections/basics" className="view-collection">
                SHOP NOW
              </Link>
            </div>
          </div>

          <div className="collection-item">
            <div className="collection-image">
              <img src="Images/IMAGE 2.jpg" alt="Urban Collection" />
            </div>
            <div className="collection-info">
              <h3>URBAN</h3>
              <Link to="/collections/urban" className="view-collection">
                SHOP NOW
              </Link>
            </div>
          </div>

          <div className="collection-item">
            <div className="collection-image">
              <img src="Images/IMAGE 3.jpg" alt="Streetwear Collection" />
            </div>
            <div className="collection-info">
              <h3>STREETWEAR</h3>
              <Link to="/collections/streetwear" className="view-collection">
                SHOP NOW
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about-section">
        <div className="about-content">
          <h2>ABOUT UNDERGOLD</h2>
          <p>
            Dedicated to urban culture and streetwear aesthetics, our brand brings you premium quality clothing with a
            distinctive style. Each piece is carefully designed to reflect the essence of urban lifestyle.
          </p>
          <Link to="/about" className="learn-more-btn">
            LEARN MORE
          </Link>
        </div>
      </section>
    </div>
  )
}

export default Home
