import React, { useState } from "react";
import "./SimilarClothes.css";

function SimilarClothes() {
  const [imageUrl, setImageUrl] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    setLoading(true);
    setResults([]);

    const url = `https://similar-clothes-ai.p.rapidapi.com/similar-clothes`;
    const options = {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "X-RapidAPI-Key": "1ceee1a8abmshdd80753e27ab7ddp10a54djsnc96a1441cbd4",      // ← pon aquí tu clave de API
        "X-RapidAPI-Host": "similar-clothes-ai.p.rapidapi.com"
      },
      body: JSON.stringify({ image_url: imageUrl })
    };

    try {
      const res = await fetch(url, options);
      const data = await res.json();
      setResults(data.similar_clothes || []);
    } catch (error) {
      console.error("Error al consumir la API:", error);
    }

    setLoading(false);
  };

  return (
    <div className="similar-clothes">
      <h2>SEARCH CLOTHES</h2>
      <input
        type="text"
        placeholder="URL de imagen de prenda"
        value={imageUrl}
        onChange={(e) => setImageUrl(e.target.value)}
      />
      <button onClick={handleSearch}>SEARCH</button>

      {loading && <p>LOADING</p>}

      <div className="results">
        {results.map((item, index) => (
          <div key={index} className="clothing-item">
            <img src={item.image_url} alt="Similar cloth" />
            <p>{item.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SimilarClothes;
