import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-left">
        <ul className="navbar-links">
          <li><Link to="/">HOME</Link></li>
          <li><Link to="/chat">CHAT</Link></li>
          <li><Link to="/clothes">PRODUCTS</Link></li>
          <li><Link to="/products">C A A</Link></li>
        </ul>
      </div>

      <div className="navbar-logo">UNDERGOLD</div>

      <div className="navbar-right">
        <ul className="navbar-links">
        </ul>
        <div className="navbar-icon">
          <i className="fas fa-search"></i>
        </div>
        <div className="navbar-icon">
          <i className="fas fa-user"></i>
        </div>
        <div className="navbar-icon">
          <i className="fas fa-shopping-bag"></i>
        </div>
        <button 
          className="mobile-menu-btn" 
          style={{ display: 'none' }}
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          <i className={mobileMenuOpen ? "fas fa-times" : "fas fa-bars"}></i>
        </button>
      </div>
    </nav>
  );
}

export default Navbar;