import { useState, useEffect } from "react"
import "./Products.css"

const Api = () => {
  const [products, setProducts] = useState([])
  const [filteredProducts, setFilteredProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [cart, setCart] = useState([])
  const [showCart, setShowCart] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [sortBy, setSortBy] = useState("default")
  const [priceRange, setPriceRange] = useState({ min: 0, max: 1000 })

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true)

        const productsResponse = await fetch("https://fakestoreapi.com/products")
        if (!productsResponse.ok) throw new Error("Error al cargar productos")
        const productsData = await productsResponse.json()

        const clothingProducts = productsData.filter(
          (product) => product.category.includes("clothing") || product.category.includes("jewelery"),
        )

        setProducts(clothingProducts)
        setFilteredProducts(clothingProducts)

        const uniqueCategories = [...new Set(clothingProducts.map((product) => product.category))]
        setCategories(uniqueCategories)

        setLoading(false)
      } catch (error) {
        console.error("Error:", error)
        setError(error.message)
        setLoading(false)
      }
    }

    fetchProducts()

    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      setCart(JSON.parse(savedCart))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
  }, [cart])

  useEffect(() => {
    if (products.length > 0) {
      let result = [...products]

      if (selectedCategory !== "all") {
        result = result.filter((product) => product.category === selectedCategory)
      }

      if (searchTerm) {
        result = result.filter(
          (product) =>
            product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.description.toLowerCase().includes(searchTerm.toLowerCase()),
        )
      }

      result = result.filter((product) => product.price >= priceRange.min && product.price <= priceRange.max)

      if (sortBy === "price-asc") {
        result.sort((a, b) => a.price - b.price)
      } else if (sortBy === "price-desc") {
        result.sort((a, b) => b.price - a.price)
      } else if (sortBy === "rating") {
        result.sort((a, b) => b.rating.rate - a.rating.rate)
      }

      setFilteredProducts(result)
    }
  }, [products, selectedCategory, searchTerm, sortBy, priceRange])

  const addToCart = (product, quantity = 1) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id)

      if (existingItem) {
        return prevCart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item))
      } else {
        return [...prevCart, { ...product, quantity }]
      }
    })

    alert(`${product.title} agregado al carrito`)
  }

  const removeFromCart = (productId) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== productId))
  }

  const updateCartQuantity = (productId, newQuantity) => {
    if (newQuantity < 1) return

    setCart((prevCart) => prevCart.map((item) => (item.id === productId ? { ...item, quantity: newQuantity } : item)))
  }

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const formatPrice = (price) => {
    return `$${price.toFixed(2)}`
  }

  const handleProductClick = (product) => {
    setSelectedProduct(product)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const handleBackClick = () => {
    setSelectedProduct(null)
  }

  const renderRatingStars = (rating) => {
    const fullStars = Math.floor(rating)
    const hasHalfStar = rating % 1 >= 0.5

    return (
      <div className="rating">
        {[...Array(5)].map((_, index) => (
          <span
            key={index}
            className={
              index < fullStars ? "star full" : index === fullStars && hasHalfStar ? "star half" : "star empty"
            }
          >
            ★
          </span>
        ))}
        <span className="rating-text">({rating})</span>
      </div>
    )
  }

  const renderCart = () => {
    return (
      <div className="cart-modal">
        <div className="cart-content">
          <div className="cart-header">
            <h2>SHOPPING CAR</h2>
            <button className="close-cart" onClick={() => setShowCart(false)}>
              ×
            </button>
          </div>

          {cart.length === 0 ? (
            <div className="empty-cart">
              <p>Empty Car</p>
              <button className="continue-shopping" onClick={() => setShowCart(false)}>
                Keep Shopping
              </button>
            </div>
          ) : (
            <>
              <div className="cart-items">
                {cart.map((item) => (
                  <div key={item.id} className="cart-item">
                    <img src={item.image || "/placeholder.svg"} alt={item.title} className="cart-item-image" />
                    <div className="cart-item-details">
                      <h4>{item.title}</h4>
                      <p className="cart-item-price">{formatPrice(item.price)}</p>
                    </div>
                    <div className="cart-item-actions">
                      <div className="quantity-controls">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          -
                        </button>
                        <span>{item.quantity}</span>
                        <button onClick={() => updateCartQuantity(item.id, item.quantity + 1)}>+</button>
                      </div>
                      <button className="remove-item" onClick={() => removeFromCart(item.id)}>
                        Delete.
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="cart-summary">
                <div className="cart-total">
                  <span>Total:</span>
                  <span>{formatPrice(calculateTotal())}</span>
                </div>
                <button className="checkout-button">Pay</button>
                <button className="continue-shopping" onClick={() => setShowCart(false)}>
                  Keep Shopping.
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    )
  }

  // Renderizar detalles de un producto
  const renderProductDetails = () => {
    if (!selectedProduct) return null

    return (
      <div className="product-details">
        <button className="back-button" onClick={handleBackClick}>
          &larr; Back to Shop
        </button>

        <div className="product-detail-content">
          <div className="product-image-container">
            <img
              src={selectedProduct.image || "/placeholder.svg"}
              alt={selectedProduct.title}
              className="product-detail-image"
            />
          </div>

          <div className="product-info">
            <h2 className="product-title">{selectedProduct.title}</h2>

            <div className="product-meta">
              <span className="product-category">
                {selectedProduct.category.charAt(0).toUpperCase() + selectedProduct.category.slice(1)}
              </span>
              {renderRatingStars(selectedProduct.rating.rate)}
              <span className="product-reviews">{selectedProduct.rating.count} Reviews</span>
            </div>

            <div className="product-price">{formatPrice(selectedProduct.price)}</div>

            <div className="product-description">
              <h3>Description</h3>
              <p>{selectedProduct.description}</p>
            </div>

            <div className="product-actions">
              <div className="quantity-selector">
                <button
                  className="quantity-btn"
                  onClick={() => {
                    const quantityInput = document.getElementById("quantity")
                    if (quantityInput.value > 1) {
                      quantityInput.value = Number.parseInt(quantityInput.value) - 1
                    }
                  }}
                >
                  -
                </button>
                <input type="number" id="quantity" min="1" defaultValue="1" className="quantity-input" />
                <button
                  className="quantity-btn"
                  onClick={() => {
                    const quantityInput = document.getElementById("quantity")
                    quantityInput.value = Number.parseInt(quantityInput.value) + 1
                  }}
                >
                  +
                </button>
              </div>

              <button
                className="add-to-cart-btn"
                onClick={() => {
                  const quantityInput = document.getElementById("quantity")
                  const quantity = Number.parseInt(quantityInput.value)
                  addToCart(selectedProduct, quantity)
                }}
              >
                Add Shopping Car
              </button>
            </div>

            <div className="product-extra-info">
              <div className="info-item">
                <span className="info-icon">🚚</span>
                <span>Free Delivery</span>
              </div>
              <div className="info-item">
                <span className="info-icon">↩️</span>
                <span>Free Devolutions</span>
              </div>
              <div className="info-item">
                <span className="info-icon">🔒</span>
                <span>Secure Pay</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (loading && !products.length) return <div className="loading">Loading Products...</div>
  if (error && !products.length) return <div className="error">Error: {error}</div>

  return (
    <div className="store-app">
      <header className="store-header">
        <div className="header-content">
          <h1>FASHION STORE</h1>
          <p>You Virtual Shop</p>
        </div>

        <div className="header-actions">
          <button className="cart-button" onClick={() => setShowCart(true)}>
            🛒 Car ({cart.reduce((total, item) => total + item.quantity, 0)})
          </button>
        </div>
      </header>

      {showCart && renderCart()}

      {selectedProduct ? (
        renderProductDetails()
      ) : (
        <div className="store-container">
          <div className="sidebar">
            <div className="filter-section">
              <h3>Categories</h3>
              <div className="category-filters">
                <label className="category-option">
                  <input
                    type="radio"
                    name="category"
                    value="all"
                    checked={selectedCategory === "all"}
                    onChange={() => setSelectedCategory("all")}
                  />
                  <span>All Categories</span>
                </label>

                {categories.map((category) => (
                  <label key={category} className="category-option">
                    <input
                      type="radio"
                      name="category"
                      value={category}
                      checked={selectedCategory === category}
                      onChange={() => setSelectedCategory(category)}
                    />
                    <span>{category.charAt(0).toUpperCase() + category.slice(1)}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="filter-section">
              <h3>Price</h3>
              <div className="price-range">
                <div className="price-inputs">
                  <div className="price-input-group">
                    <label>Min:</label>
                    <input
                      type="number"
                      min="0"
                      max={priceRange.max}
                      value={priceRange.min}
                      onChange={(e) => setPriceRange({ ...priceRange, min: Number(e.target.value) })}
                    />
                  </div>
                  <div className="price-input-group">
                    <label>Max:</label>
                    <input
                      type="number"
                      min={priceRange.min}
                      value={priceRange.max}
                      onChange={(e) => setPriceRange({ ...priceRange, max: Number(e.target.value) })}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="filter-section">
              <h3>Order By</h3>
              <div className="sort-options">
                <label className="sort-option">
                  <input
                    type="radio"
                    name="sort"
                    value="default"
                    checked={sortBy === "default"}
                    onChange={() => setSortBy("default")}
                  />
                  <span>Highlights</span>
                </label>
                <label className="sort-option">
                  <input
                    type="radio"
                    name="sort"
                    value="price-asc"
                    checked={sortBy === "price-asc"}
                    onChange={() => setSortBy("price-asc")}
                  />
                  <span>Price: Minur to Major</span>
                </label>
                <label className="sort-option">
                  <input
                    type="radio"
                    name="sort"
                    value="price-desc"
                    checked={sortBy === "price-desc"}
                    onChange={() => setSortBy("price-desc")}
                  />
                  <span>Price: Major to Minur</span>
                </label>
                <label className="sort-option">
                  <input
                    type="radio"
                    name="sort"
                    value="rating"
                    checked={sortBy === "rating"}
                    onChange={() => setSortBy("rating")}
                  />
                  <span>Bests.</span>
                </label>
              </div>
            </div>
          </div>

          <div className="main-content">
            <div className="search-bar">
              <input
                type="text"
                placeholder="SEARCH"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
            </div>

            <div className="products-count">Showing {filteredProducts.length} products</div>

            <div className="products-grid">
              {filteredProducts.length > 0 ? (
                filteredProducts.map((product) => (
                  <div key={product.id} className="product-card">
                    <div className="product-image-wrapper" onClick={() => handleProductClick(product)}>
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.title}
                        className="product-image"
                        loading="lazy"
                      />
                    </div>
                    <div className="product-card-info">
                      <h3 className="product-card-title" onClick={() => handleProductClick(product)}>
                        {product.title}
                      </h3>
                      <div className="product-card-meta">{renderRatingStars(product.rating.rate)}</div>
                      <div className="product-card-price">{formatPrice(product.price)}</div>
                      <button className="quick-add-btn" onClick={() => addToCart(product)}>
                        Add Shopping Car
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="no-results">No Products Found</div>
              )}
            </div>
          </div>
        </div>
      )}

      <footer className="store-footer">
        <div className="footer-content">
          <div className="footer-section">
            <h3>Fashion Store</h3>
            <p>Your Best Option</p>
          </div>
          <div className="footer-section">
            <h3>Quick Links</h3>
            <ul>
              <li>
                <a href="#">Home</a>
              </li>
              <li>
                <a href="#">Products</a>
              </li>
              <li>
                <a href="#">Us</a>
              </li>
              <li>
                <a href="#">Contact</a>
              </li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>Contact</h3>
            <p>📍 ANY</p>
            <p>📞 3177396344</p>
            <p>✉️ josebetancourtcsfn@gmail.com</p>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; 2025.</p>
        </div>
      </footer>
    </div>
  )
}

export default Api
