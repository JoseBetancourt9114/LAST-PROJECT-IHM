import { useState } from "react";
import axios from "axios";
import "./CompApi.css";

export default function CompAPi() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (input.trim() === "") return;

    const newMessages = [...messages, { sender: "user", text: input }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-7b-instruct", 
        messages: newMessages.map((m) => ({
          role: m.sender === "user" ? "user" : "assistant",
          content: m.text,
        })),
      },
      {
        headers: {
          Authorization: `Bearer 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`,
          "Content-Type": "application/json",
          "X-Title": "AstronautGPT",
        },
      }
    );


      const botReply = response.data.choices[0].message.content;
      setMessages([...newMessages, { sender: "bot", text: botReply }]);
    } catch (error) {
      console.error("Error on API:", error);
      setMessages([...newMessages, { sender: "bot", text: "Error at getting the answer" }]);
    }
    setLoading(false);
  };

  return (
    <div className="chat-container">
      <div className="header d-flex justify-content-center align-items-center mb-4">
        <img
          src="Images/LOGO.png"
          alt="astronaut-icon"
          className="icon me-2 animate__animated animate__fadeIn"
        />
      </div>

      <div className="chat-box">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`message ${msg.sender === "user" ? "user" : "bot"}`}
          >
            <div className="bubble">{msg.text}</div>
          </div>
        ))}
        {loading && (
          <div className="message bot">
            <div className="bubble typing">Loading</div>
          </div>
        )}
      </div>

      <div className="input-area input-group mt-3">
        <input
          type="text"
          className="form-control"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder="Type"
          disabled={loading}
        />
        <button
          className="btn btn-info"
          onClick={sendMessage}
          disabled={loading || input.trim() === ""}
        >
          Send
        </button>
      </div>
    </div>
  );
}